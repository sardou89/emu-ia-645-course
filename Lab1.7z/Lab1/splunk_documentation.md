## This script will install Splunk Free in a Docker Container which will be able to be used locally. 

- The username is admin and password is password. Not for Production use.

I was able to use this documentation to recreate this a format that students are able to use and interact with.
    * Main Document - https://splunk.github.io/docker-splunk/
    * Specfic Deployment Type - https://splunk.github.io/docker-splunk/EXAMPLES.html#create-standalone-with-splunk-free-license


- acloudsecninja - Professor Weber